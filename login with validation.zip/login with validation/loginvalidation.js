function loginvalidation(){
var x=document.myform.username.value;
var atposition=x.indexOf("@");
var dotposition=x.lastIndexOf(".");
if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){ alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\ndotposition:"+dotposition);
 return false;
 }
}
